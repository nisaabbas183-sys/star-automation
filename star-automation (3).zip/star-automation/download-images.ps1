[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$base = "https://starautomation.net/"
$root = Join-Path (Get-Location) "public\images"
$script:ok = 0
$script:fail = @()

function Get-Img([string]$src, [string]$dest) {
    $url = $base + ($src -replace ' ', '%20' -replace '\(', '%28' -replace '\)', '%29')
    $out = Join-Path $root $dest
    New-Item -ItemType Directory -Force -Path (Split-Path $out) | Out-Null
    try {
        Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing
        $script:ok++
    } catch {
        $script:fail += $src
        Write-Host "FAILED: $src" -ForegroundColor Red
    }
}

# ---- Hero slider
$slides = @("bg6.png","bg1.png","bg2.png","bg5.png","bg3.png","bg4.png")
for ($i = 0; $i -lt $slides.Count; $i++) {
    Get-Img "assets/images/slider/$($slides[$i])" "slides\slide-$($i+1).png"
}

# ---- Projects carousel
$projects = @("1s.jpg","2s.png","3s.jpg","4s.jpg","5s.jpg","6s.jpg","7s.jpg","8s.jpg")
for ($i = 0; $i -lt $projects.Count; $i++) {
    $ext = [IO.Path]::GetExtension($projects[$i])
    Get-Img "assets/images/portfolio/$($projects[$i])" "projects\project-$($i+1)$ext"
}

# ---- Software screenshots
Get-Img "assets/images/1.png"   "software\ems.png"
Get-Img "assets/images/p-3.png" "software\accounting.png"
Get-Img "assets/images/p-4.png" "software\inventory.png"
Get-Img "assets/images/p-2.png" "software\quotation.png"
Get-Img "assets/images/p-1.png" "software\task.png"

# ---- Partner logos
Get-Img "assets/images/team/L1.png"   "brands\azbil.png"
Get-Img "logo/me.jpeg"                "brands\mitsubishi-electric.jpeg"
Get-Img "assets/images/team/L105.png" "brands\dwyer-omega.png"
Get-Img "assets/images/team/L2.png"   "brands\schuf.png"
Get-Img "logo/gf.jpeg"                "brands\gf-piping.jpeg"
Get-Img "assets/images/team/L4.jpg"   "brands\daiichi.jpg"
Get-Img "assets/images/team/L6.jpg"   "brands\kinda.jpg"
Get-Img "assets/images/team/L3.jpg"   "brands\bc-electronics.jpg"

Write-Host ""
Write-Host "Downloaded: $script:ok files" -ForegroundColor Green
if ($script:fail.Count -gt 0) {
    Write-Host "Failed: $($script:fail.Count)" -ForegroundColor Yellow
    $script:fail | ForEach-Object { Write-Host "  $_" }
}