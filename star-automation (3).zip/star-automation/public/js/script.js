document.addEventListener('DOMContentLoaded', function () {

    /* ---------- Projects carousel ---------- */
    var carousel = document.querySelector('[data-carousel]');
    if (carousel) {
        var track = carousel.querySelector('.carousel-track');
        var stepBy = function () { return track.clientWidth * 0.8; };

        carousel.querySelector('.carousel-prev').addEventListener('click', function () {
            track.scrollBy({ left: -stepBy(), behavior: 'smooth' });
        });
        carousel.querySelector('.carousel-next').addEventListener('click', function () {
            track.scrollBy({ left: stepBy(), behavior: 'smooth' });
        });
    }

    /* ---------- Product category tabs ---------- */
    var tabs = document.querySelectorAll('[data-tab]');
    var panels = document.querySelectorAll('[data-panel]');
    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            var id = tab.getAttribute('data-tab');
            tabs.forEach(function (t) { t.classList.toggle('is-active', t === tab); });
            panels.forEach(function (p) {
                p.classList.toggle('is-active', p.getAttribute('data-panel') === id);
            });
        });
    });

    /* ---------- Home hero: live SCADA dashboard ---------- */
    var dash = document.querySelector('.dash');
    if (dash) {
        var still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var rnd = function (a, b) { return a + Math.random() * (b - a); };
        var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

        var needle = dash.querySelector('#g-needle');
        var gfill = dash.querySelector('#g-fill');
        var gval = dash.querySelector('#g-val');
        var p = 4.6, gMax = 10;

        var stats = [].map.call(dash.querySelectorAll('[data-live]'), function (el) {
            var min = parseFloat(el.dataset.min), max = parseFloat(el.dataset.max);
            return {
                el: el, min: min, max: max,
                dec: parseInt(el.dataset.dec || '0', 10),
                unit: el.dataset.unit || '',
                v: min + (max - min) * rnd(0.4, 0.6),
                bar: el.closest('.dash-stat').querySelector('.bar u')
            };
        });

        var W = 300, H = 70, N = 40, step = W / (N - 1), trend = [], base = rnd(35, 50), k;
        for (k = 0; k <= N; k++) {
            base = clamp(base + rnd(-7, 7), 10, 60);
            trend.push(base);
        }
        var line = dash.querySelector('.c-line');
        var area = dash.querySelector('.c-area');
        var sc = dash.querySelector('.c-scroll');

        var draw = function () {
            var d = '';
            trend.forEach(function (y, i) {
                d += (i ? 'L' : 'M') + ((i - 1) * step).toFixed(1) + ' ' + (H - y).toFixed(1) + ' ';
            });
            line.setAttribute('d', d);
            area.setAttribute('d', d + 'L' + W + ' ' + H + ' L' + (-step) + ' ' + H + ' Z');
        };

        var tick = function (first) {
            p = clamp(p + rnd(-0.9, 0.9), 1.5, 8.5);
            needle.style.transform = 'rotate(' + (-90 + p / gMax * 180).toFixed(1) + 'deg)';
            gfill.style.strokeDasharray = (p / gMax * 100).toFixed(1) + ' 100';
            gval.textContent = p.toFixed(1);

            stats.forEach(function (s) {
                var r = s.max - s.min;
                s.v = clamp(s.v + (Math.random() - 0.5) * r * 0.12, s.min, s.max);
                s.el.textContent = s.v.toFixed(s.dec) + ' ' + s.unit;
                if (s.bar) { s.bar.style.width = ((s.v - s.min) / r * 100) + '%'; }
            });

            if (!first) {
                trend.shift();
                trend.push(clamp(trend[trend.length - 1] + rnd(-9, 9), 10, 60));
            }
            draw();

            if (!first && !still) {
                sc.style.transition = 'none';
                sc.style.transform = 'translateX(' + step + 'px)';
                sc.getBoundingClientRect();
                sc.style.transition = 'transform .95s linear';
                sc.style.transform = 'translateX(0)';
            }
        };

        tick(true);
        if (!still) { setInterval(tick, 1000); }
    }
});