[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$base = "https://starautomation.net/"
$root = Join-Path (Get-Location) "public\images"
$script:ok = 0
$script:fail = @()

function Get-Img([string]$src, [string]$dest) {
    $url = $base + ($src -replace ' ', '%20' -replace '\(', '%28' -replace '\)', '%29')
    $out = Join-Path $root $dest
    New-Item -ItemType Directory -Force -Path (Split-Path $out) | Out-Null
    try {
        Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing
        $script:ok++
    } catch {
        $script:fail += $src
        Write-Host "FAILED: $src" -ForegroundColor Red
    }
}

# ---- Products (portfolio folder)
$nums = "01","02","03","04","05","07","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","51","52","53","54","55","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","78","79","80","81","82","83","84","86"
foreach ($n in $nums) { Get-Img "assets/images/portfolio/$n.jpg" "products\p-$n.jpg" }
Get-Img "assets/images/portfolio/121.JPG" "products\p-121.jpg"

# ---- Products (other folders)
$others = @(
    @("flowmeter/Electromagnetic Flow meter.jpg", "p-flow-electromagnetic.jpg"),
    @("flowmeter/Paddle Wheel Flow meter (2).jpg", "p-flow-paddle-2.jpg"),
    @("flowmeter/Paddle Wheel Flow meter.jpg", "p-flow-paddle.jpg"),
    @("temperature/TT1.jpeg", "p-temp-tt1.jpeg"),
    @("temperature/TT2.jpeg", "p-temp-tt2.jpeg"),
    @("control valve/22.jpg", "p-cv-22.jpg"),
    @("control valve/88.jpg", "p-cv-88.jpg"),
    @("control valve/99.jpg", "p-cv-99.jpg"),
    @("control valve/111.jpg", "p-cv-111.jpg"),
    @("controller/multichannel.jpg", "p-multichannel.jpg"),
    @("controller/Fatek PLC.jpg", "p-fatek-plc.jpg"),
    @("controller/Mitsubihi PLC.png", "p-mitsubishi-plc.png"),
    @("mit/4.jpeg", "p-energy-meter.jpeg"),
    @("controller/c1.jpeg", "p-servo-drives.jpeg"),
    @("controller/c2.jpeg", "p-hmi.jpeg"),
    @("controller/Siemens PLC.jpg", "p-siemens-plc.jpg"),
    @("gf/1.jpeg", "p-gf-1.jpeg"),
    @("gf/2.jpeg", "p-gf-2.jpeg"),
    @("vfx/vf.jpeg", "p-vfd-vf.jpeg"),
    @("breakers/ACB.png", "p-acb.png"),
    @("breakers/MCCB.jpg", "p-mccb.jpg"),
    @("breakers/MCB.jpg", "p-mcb.jpg"),
    @("contactors/contactors.png", "p-contactors.png"),
    @("relays/1.jpeg", "p-relay-1.jpeg"),
    @("relays/2.jpeg", "p-relay-2.jpeg")
)
foreach ($o in $others) { Get-Img $o[0] ("products\" + $o[1]) }

Write-Host ""
Write-Host "Downloaded: $script:ok files" -ForegroundColor Green
if ($script:fail.Count -gt 0) {
    Write-Host "Failed: $($script:fail.Count)" -ForegroundColor Yellow
    $script:fail | ForEach-Object { Write-Host "  $_" }
}