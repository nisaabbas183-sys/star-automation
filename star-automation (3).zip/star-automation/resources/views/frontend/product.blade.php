@extends('layouts.app')

@section('title', $product->name . ' in Pakistan | Star Automation')
@section('description', $product->name . ' supplied and supported by Star Automation, Lahore, Pakistan.')

@section('content')

<section class="product-head">
    <div class="container">
        <nav class="crumbs">
            <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <a href="{{ route('products') }}">Products</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>{{ $product->category->name }}</span>
        </nav>
    </div>
</section>

<section class="section">
    <div class="container pd">
        <div class="pd-image">
            @if ($product->image)
                <img src="{{ asset('images/products/' . $product->image) }}" alt="{{ $product->name }}">
            @else
                <span class="no-image">Image coming soon</span>
            @endif
        </div>

        <div class="pd-info">
            <span class="pd-cat">{{ $product->category->name }}</span>
            <h1>{{ $product->name }}</h1>
            @if ($product->short_description)
                <p class="pd-type">{{ $product->short_description }}</p>
            @endif

            <table class="pd-table">
                <tr>
                    <th>Category</th>
                    <td>{{ $product->category->name }}</td>
                </tr>
                @if ($product->short_description)
                    <tr>
                        <th>Type</th>
                        <td>{{ $product->short_description }}</td>
                    </tr>
                @endif
                <tr>
                    <th>Supplied by</th>
                    <td>Star Automation, Lahore, Pakistan</td>
                </tr>
                <tr>
                    <th>Services</th>
                    <td>Application, installation, configuration and commissioning</td>
                </tr>
            </table>

           <div class="pd-actions">
    <a href="{{ route('contact', ['product' => $product->name]) }}" class="btn btn-primary btn-icon">
        <i class="bi bi-envelope-paper"></i> Request a Quote
    </a>
    <a href="https://wa.me/923214988683?text={{ urlencode('Hello, I would like a quote for: ' . $product->name) }}" class="btn btn-whatsapp btn-icon" target="_blank" rel="noopener">
        <i class="bi bi-whatsapp"></i> WhatsApp
    </a>
</div>
        </div>
    </div>
</section>

@if ($related->isNotEmpty())
<section class="section section-soft">
    <div class="container">
        <span class="eyebrow">More in {{ $product->category->name }}</span>
        <h2>Related Products</h2>

        <div class="product-grid" style="margin-top:28px">
            @foreach ($related as $item)
                <a href="{{ route('product.show', $item->slug) }}" class="product-card">
                    <div class="product-img">
                        @if ($item->short_description)
                            <span class="product-tag">{{ $item->short_description }}</span>
                        @endif
                        @if ($item->image)
                            <img src="{{ asset('images/products/' . $item->image) }}" alt="{{ $item->name }}" loading="lazy">
                        @else
                            <span class="no-image">Image coming soon</span>
                        @endif
                    </div>
                    <div class="product-body">
                        <h3>{{ $item->name }}</h3>
                        <span class="product-link">View Details →</span>
                    </div>
                </a>
            @endforeach
        </div>
    </div>
</section>
@endif

@endsection