@extends('layouts.app')

@section('title', 'Automation, SCADA & Software Projects | Star Automation')
@section('description', 'Process automation, boiler and AHU automation, SCADA monitoring and software projects delivered by Star Automation in Pakistan.')

@section('content')

@php
$projects = [
    ['project-1.jpg', 'Process Automation', 'Automation'],
    ['project-2.png', 'Process Automation', 'Automation'],
    ['project-3.jpg', 'SCADA for Humidity & Temperature', 'SCADA'],
    ['project-4.jpg', 'SCADA for Humidity & Temperature', 'SCADA'],
    ['project-5.jpg', 'Online Telemedicine Software', 'Software'],
    ['project-6.jpg', 'Boiler Automation', 'Automation'],
    ['project-7.jpg', 'Account Software', 'Software'],
    ['project-8.jpg', 'AHU Automation', 'Automation'],
];
@endphp

<section class="page-banner">
    @include('partials.banner-art')
    <div class="container">
        <nav class="crumbs">
            <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>Projects</span>
        </nav>
        <h1>Our Projects</h1>
        <p>Automation, SCADA and software systems we have delivered.</p>
    </div>
</section>

<section class="section" id="gallery">
    <div class="container">
        <span class="eyebrow">Portfolio</span>
        <h2>Projects Delivered Across Industry</h2>
        <p class="section-intro">From process and boiler automation to online SCADA and web-based software. Click a project to enlarge it.</p>

     @php
    $counts = collect($projects)->countBy(fn ($p) => $p[2]);
@endphp

<div class="pj-filter">
    <input type="radio" name="pjf" id="pf-all" checked>
    <input type="radio" name="pjf" id="pf-auto">
    <input type="radio" name="pjf" id="pf-scada">
    <input type="radio" name="pjf" id="pf-soft">

    <div class="pj-pills">
        <label for="pf-all">All <em>{{ count($projects) }}</em></label>
        <label for="pf-auto">Automation <em>{{ $counts['Automation'] ?? 0 }}</em></label>
        <label for="pf-scada">SCADA <em>{{ $counts['SCADA'] ?? 0 }}</em></label>
        <label for="pf-soft">Software <em>{{ $counts['Software'] ?? 0 }}</em></label>
    </div>

    <div class="pj-grid">
        @foreach ($projects as $i => $p)
            <a href="#proj-{{ $i + 1 }}" class="pj-card" data-cat="{{ $p[2] }}">
                <img src="{{ asset('images/projects/' . $p[0]) }}" alt="{{ $p[1] }}" loading="lazy">
                <span class="pj-badge">{{ $p[2] }}</span>
                <div class="pj-over">
                    <h3>{{ $p[1] }}</h3>
                    <span class="pj-view">View project <i class="bi bi-arrow-up-right"></i></span>
                </div>
            </a>
        @endforeach
    </div>
</div>

        <div class="pj-cta">
            <div>
                <h3>Have a project in mind?</h3>
                <p>Tell us your requirement and our engineers will get back to you.</p>
            </div>
            <a href="{{ route('contact') }}" class="btn btn-primary btn-icon"><i class="bi bi-envelope-paper"></i> Request a Quote</a>
        </div>
    </div>

    @foreach ($projects as $i => $p)
        <div class="pj-lb" id="proj-{{ $i + 1 }}">
            <a href="#gallery" class="pj-lb-bg" aria-label="Close"></a>
            <a href="#gallery" class="pj-lb-close" aria-label="Close">&times;</a>
            <figure>
                <img src="{{ asset('images/projects/' . $p[0]) }}" alt="{{ $p[1] }}">
                <figcaption>{{ $p[1] }}</figcaption>
            </figure>
        </div>
    @endforeach
</section>

@endsection