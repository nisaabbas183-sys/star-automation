@extends('layouts.app')

@section('title', 'International Brands We Represent in Pakistan | Star Automation')
@section('description', 'Star Automation represents Azbil, Dwyer Omega, Mitsubishi Electric, SCHUF, GF Piping, Daiichi, Kinda and B&C Electronics in Pakistan.')

@section('content')

<section class="page-banner">
    @include('partials.banner-art')
    <div class="container">
        <nav class="crumbs">
            <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>Brands</span>
        </nav>
        <h1>Our Brands</h1>
        <p>International principals we represent in Pakistan.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <span class="eyebrow">Partners</span>
        <h2>Equipment from leading Manufacturers</h2>
        <p class="section-intro">We supply, configure and support products from trusted manufacturers around the world.</p>

        <div class="brand-grid">
    @foreach ($brands as $brand)
        <a href="{{ route('contact', ['product' => $brand->name]) }}" class="tile" id="{{ $brand->slug }}" title="Request a quote for {{ $brand->name }}">
            <span class="tile-arrow"><i class="bi bi-arrow-up-right"></i></span>

            <span class="tile-logo">
                @if ($brand->logo)
                    <img src="{{ asset('images/brands/' . $brand->logo) }}" alt="{{ $brand->name }}" loading="lazy">
                @else
                    <i class="bi bi-gear-wide-connected"></i>
                @endif
            </span>

            <span class="tile-meta">
                <strong>{{ $brand->name }}</strong>
                <em><i class="bi bi-geo-alt"></i> {{ $brand->country }}</em>
            </span>
        </a>
    @endforeach
</div>
        
    </div>
</section>

@endsection