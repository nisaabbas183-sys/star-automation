@extends('layouts.app')

@section('title', 'About Star Automation | Automation Engineering Company in Pakistan')
@section('description', 'Star Automation is a leading automation engineering company in Pakistan, supplying process equipment and providing configuration and commissioning services.')

@section('content')

<section class="page-banner">
    @include('partials.banner-art')
    <div class="container">
        <nav class="crumbs">
            <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>About Us</span>
        </nav>
        <h1>About Us</h1>
        <p>A leading automation engineering company in Pakistan.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <span class="eyebrow">Who we are</span>
        <h2>Setting High Standards of Technical Excellence</h2>

        <div class="about-split">
            <figure class="about-photo">
                <img src="{{ asset('images/activities/automation-engineering.jpg') }}" alt="Star Automation engineering services">
            </figure>

          <div class="about-text">
    <p class="about-lead">We supply industrial instruments and control equipment from leading manufacturers in the Far East, Europe and America.</p>
    <p>We also install, configure and commission them for industries, factories and buildings across Pakistan, with our own experienced engineers.</p>

    <ul class="about-points">
        <li><i class="bi bi-check-circle-fill"></i> Transmitters, analyzers, valves and controllers</li>
        <li><i class="bi bi-check-circle-fill"></i> Recorders, burners, VFDs, sensors and switches</li>
        <li><i class="bi bi-check-circle-fill"></i> PLC programming and SCADA solutions</li>
        <li><i class="bi bi-check-circle-fill"></i> Better efficiency, safety and environmental protection for your process</li>
    </ul>
</div>
        </div>
    </div>
</section>

<section class="about-stats">
    <div class="container">
        <div class="stats-card">
            <div class="stat">
                <span class="stat-icon"><i class="bi bi-geo-alt"></i></span>
                <div>
                    <strong>4</strong>
                    <span>Sales &amp; service locations</span>
                </div>
            </div>
            <div class="stat">
                <span class="stat-icon"><i class="bi bi-globe2"></i></span>
                <div>
                    <strong>8</strong>
                    <span>International principals</span>
                </div>
            </div>
            <div class="stat">
                <span class="stat-icon"><i class="bi bi-grid"></i></span>
                <div>
                    <strong>14</strong>
                    <span>Product categories</span>
                </div>
            </div>
        </div>
    </div>
</section>

@php
$strategies = [
    [
        'bi-gear-wide-connected',
        'Operational Excellence',
        'Consistent quality and reliable service, from equipment selection to commissioning.',
    ],
    [
        'bi-tools',
        'Efficient Technical Services',
        'Application, installation, configuration and commissioning by our own experienced engineers.',
    ],
    [
        'bi-cpu',
        'State of the Art Process Equipment',
        'Instruments and controls from leading Far Eastern, European and American manufacturers.',
    ],
    [
        'bi-graph-up-arrow',
        'Market Expansion',
        'Growing our reach across Pakistan through 04 sales and service locations, and supporting exports.',
    ],
];
@endphp

<section class="section section-soft">
    <div class="container">
        <span class="eyebrow">Our Strategy</span>
        <h2>Four Pillars of our Growth</h2>
        <p class="section-intro">Quality equipment, skilled engineers and a growing national network.</p>

        <div class="about-grid">
            @foreach ($strategies as $s)
                <div class="strategy">
                    <span class="strategy-icon"><i class="bi {{ $s[0] }}"></i></span>
                    <h3>{{ $s[1] }}</h3>
                    <p>{{ $s[2] }}</p>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endsection