@extends('layouts.app')

@section('title', 'Industrial Automation in Pakistan | Star Automation')
@section('description', 'Star Automation supplies instruments, control products, PLC and SCADA solutions and engineering services across Pakistan.')

@section('content')

{{-- Hero --}}
<section class="hx">
    <div class="hx-photo" aria-hidden="true"><div class="hx-img"></div></div>
    <div class="hx-band" aria-hidden="true"></div>
    <div class="hx-band2" aria-hidden="true"></div>
    <svg class="hx-net" viewBox="0 0 800 420" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <path class="n-lines" d="M40 60L180 30L330 90L500 40L640 110M40 60L90 190L250 170L330 90M180 30L250 170M500 40L420 200L250 170M640 110L580 230L420 200M90 190L60 320L200 360L250 170M200 360L360 310L420 200M360 310L520 380L580 230M520 380L700 330L580 230M700 330L700 200L640 110M360 310L250 170M420 200L330 90"/>
    <g class="n-dots">
        <circle cx="40" cy="60" r="4"/><circle cx="180" cy="30" r="3"/><circle cx="330" cy="90" r="4"/>
        <circle cx="500" cy="40" r="3"/><circle cx="640" cy="110" r="4"/><circle cx="90" cy="190" r="3"/>
        <circle cx="250" cy="170" r="5"/><circle cx="420" cy="200" r="4"/><circle cx="580" cy="230" r="3"/>
        <circle cx="60" cy="320" r="4"/><circle cx="200" cy="360" r="3"/><circle cx="360" cy="310" r="4"/>
        <circle cx="520" cy="380" r="3"/><circle cx="700" cy="330" r="4"/><circle cx="700" cy="200" r="3"/>
    </g>
</svg>

    <div class="container hx-in">
        <div class="hx-copy">
            <span class="hx-pill">Automation Engineering Company · Lahore</span>
            <h1>Industrial Automation <span>in Pakistan</span></h1>
            <p class="hx-lead">Instruments, control products and engineering services for industry and buildings, supplied from leading international principals and commissioned by our own engineers.</p>

            <div class="hx-act">
                <a href="{{ route('products') }}" class="hx-btn hx-dark">Browse Products <i class="bi bi-arrow-right"></i></a>
                <a href="{{ route('services') }}" class="hx-btn hx-line">Our Services <i class="bi bi-caret-right-fill"></i></a>
            </div>

            <ul class="hx-feats">
                <li><i class="bi bi-patch-check"></i><div><b>Trusted</b><span>Brands</span></div></li>
                <li><i class="bi bi-person-gear"></i><div><b>Expert</b><span>Engineers</span></div></li>
                <li><i class="bi bi-broadcast"></i><div><b>Online</b><span>SCADA 24/7</span></div></li>
            </ul>
        </div>
    </div>
</section>

{{-- Core Services + Trusted --}}
<section class="rw">
    <div class="container rw-in">
        <div>
            <div class="sv-head">
                <h2>Our Core Services</h2>
                <p>Comprehensive automation solutions tailored to your needs.</p>
            </div>
            <div class="sv-grid">
                <a href="{{ route('services') }}" class="sv-card">
                    <i class="bi bi-gear-wide-connected sv-ic"></i><b>Industrial Automation</b>
                    <span class="sv-go"><i class="bi bi-arrow-right"></i></span>
                </a>
                <a href="{{ route('services') }}" class="sv-card">
                    <i class="bi bi-building-gear sv-ic"></i><b>Building Automation</b>
                    <span class="sv-go"><i class="bi bi-arrow-right"></i></span>
                </a>
                <a href="{{ route('services') }}" class="sv-card">
                    <i class="bi bi-cpu sv-ic"></i><b>PLC Programming</b>
                    <span class="sv-go"><i class="bi bi-arrow-right"></i></span>
                </a>
                <a href="{{ route('services') }}" class="sv-card">
                    <i class="bi bi-broadcast sv-ic"></i><b>SCADA &amp; Monitoring</b>
                    <span class="sv-go"><i class="bi bi-arrow-right"></i></span>
                </a>
                <a href="{{ route('services') }}" class="sv-card">
                    <i class="bi bi-code-slash sv-ic"></i><b>Software Development</b>
                    <span class="sv-go"><i class="bi bi-arrow-right"></i></span>
                </a>
            </div>
        </div>

        <div class="tc">
            <h2>Trusted by Industry Leaders</h2>
            <p>Leading international principals, backed by our own engineers across Pakistan.</p>
            <a href="{{ route('brands') }}" class="tc-btn">View Our Principals <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
</section>

{{-- About band --}}
<section class="am">
    <div class="am-wrap">
        <div class="am-photo">
            <div class="am-img"></div>
            <div class="am-stripe"></div>
        </div>
        <div class="am-body">
            <div class="am-copy">
                <span class="eyebrow">About Star Automation</span>
                <h2>A leading automation engineering company in Pakistan</h2>
                <p>Star Automation is recognized as a leading supplier of Far Eastern, European and American process equipment. We ensure configuration and commissioning for industries, factories and buildings across Pakistan.</p>
                <a href="{{ route('about') }}" class="am-btn">Learn More <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="am-stats">
                <div><b>{{ $brands->count() }}</b><span>Principals</span></div>
                <div><b>{{ $categories->count() }}</b><span>Categories</span></div>
                <div><b>4</b><span>Locations</span></div>
            </div>
        </div>
    </div>
</section>

{{-- Products --}}
@php
$icons = [
    'pressure' => 'bi-speedometer2', 'flow' => 'bi-droplet-half', 'temperature' => 'bi-thermometer-half',
    'level' => 'bi-water', 'humidity' => 'bi-moisture', 'analyzers' => 'bi-activity',
    'dataloggers' => 'bi-hdd-network', 'valves' => 'bi-gear-wide-connected', 'controllers' => 'bi-cpu',
    'switches-sensors' => 'bi-toggles', 'vfds' => 'bi-lightning-charge', 'breakers' => 'bi-plug',
    'contactors' => 'bi-diagram-2', 'relays' => 'bi-toggle-on',
];
@endphp

<section class="section section-soft" id="products">
    <div class="container">
        <span class="eyebrow">Products</span>
        <h2>Our Products</h2>

        <div class="catalog">
            <aside class="catalog-nav">
                @foreach ($categories as $i => $category)
                    <button type="button" class="catalog-item {{ $i === 0 ? 'is-active' : '' }}" data-tab="{{ $category->slug }}">
                        <i class="bi {{ $icons[$category->slug] ?? 'bi-box-seam' }}"></i>
                        <span>{{ $category->name }}</span>
                        <em>{{ $category->products->count() }}</em>
                    </button>
                @endforeach
            </aside>

            <div class="catalog-body">
                @foreach ($categories as $i => $category)
                    <div class="tab-panel {{ $i === 0 ? 'is-active' : '' }}" data-panel="{{ $category->slug }}">
                        <div class="catalog-head">
                            <h3>{{ $category->name }}</h3>
                            <span>{{ $category->products->count() }} products</span>
                        </div>

                        <div class="product-grid">
                            @foreach ($category->products as $product)
                                <a href="{{ route('product.show', $product->slug) }}" class="product-card">
                                    <div class="product-img">
                                        @if ($product->short_description)
                                            <span class="product-tag">{{ $product->short_description }}</span>
                                        @endif

                                        @if ($product->image)
                                            <img src="{{ asset('images/products/' . $product->image) }}" alt="{{ $product->name }}" loading="lazy">
                                        @else
                                            <span class="no-image">Image coming soon</span>
                                        @endif
                                    </div>
                                    <div class="product-body">
                                        <h3>{{ $product->name }}</h3>
                                        <span class="product-link">View Details →</span>
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</section>

{{-- Projects --}}
@php
$projects = [
    ['project-1.jpg', 'Process Automation'],
    ['project-2.png', 'Process Automation'],
    ['project-3.jpg', 'SCADA for Humidity & Temperature'],
    ['project-4.jpg', 'SCADA for Humidity & Temperature'],
    ['project-5.jpg', 'Online Telemedicine Software'],
    ['project-6.jpg', 'Boiler Automation'],
    ['project-7.jpg', 'Account Software'],
    ['project-8.jpg', 'AHU Automation'],
];
@endphp

<section class="section" id="projects">
    <div class="container">
        <span class="eyebrow">Projects</span>
        <h2>Our Automation Projects</h2>
        <p class="section-intro">A selection of process, building and software projects delivered by our team.</p>

        <div class="carousel" data-carousel>
            <button type="button" class="carousel-arrow carousel-prev" aria-label="Previous">‹</button>
            <div class="carousel-track">
                @foreach ($projects as $p)
                    <figure class="carousel-item">
                        <img src="{{ asset('images/projects/' . $p[0]) }}" alt="{{ $p[1] }}" loading="lazy">
                        <figcaption>{{ $p[1] }}</figcaption>
                    </figure>
                @endforeach
            </div>
            <button type="button" class="carousel-arrow carousel-next" aria-label="Next">›</button>
        </div>
    </div>
</section>

{{-- Software --}}
@php
$software = [
    ['accounting.png', 'Accounting System'],
    ['inventory.png', 'Inventory System'],
    ['quotation.png', 'Quotation System'],
    ['task.png', 'Task Management'],
    ['ems.png', 'Education Management System'],
];
@endphp

<section class="section section-soft" id="software">
    <div class="container">
        <span class="eyebrow">Software</span>
        <h2>Software We Develop</h2>
        <p class="section-intro">Customized web-based systems built for our clients.</p>

        <div class="carousel" data-carousel>
            <button type="button" class="carousel-arrow carousel-prev" aria-label="Previous">‹</button>
            <div class="carousel-track">
                @foreach ($software as $s)
                    <figure class="carousel-item">
                        <img src="{{ asset('images/software/' . $s[0]) }}" alt="{{ $s[1] }}" loading="lazy">
                        <figcaption>{{ $s[1] }}</figcaption>
                    </figure>
                @endforeach
            </div>
            <button type="button" class="carousel-arrow carousel-next" aria-label="Next">›</button>
        </div>
    </div>
</section>

{{-- Partners --}}
@php
$brandItems = $brands->map(function ($b) {
    $logo = null;
    foreach (['png', 'webp', 'jpg', 'jpeg', 'svg'] as $ext) {
        $path = 'images/brands/' . $b->slug . '.' . $ext;
        if (file_exists(public_path($path))) {
            $logo = asset($path);
            break;
        }
    }
    return (object) ['name' => $b->name, 'country' => $b->country, 'logo' => $logo];
});
$rows = [$brandItems];
@endphp

<section class="section" id="partners">
    <div class="container">
        <span class="eyebrow">Partners</span>
        <h2>International Principals We Represent</h2>
        <p class="partners-lead">Trusted manufacturers from around the world, supplied and supported by our own engineers in Pakistan.</p>

        @if ($brands->isNotEmpty())
            <div class="marquee">
                @foreach ($rows as $r => $items)
                    <div class="marquee-row {{ $r ? 'is-reverse' : '' }}">
                        <div class="marquee-track">
                            @for ($copy = 0; $copy < 2; $copy++)
                                @foreach ($items as $b)
                                    <a href="{{ route('brands') }}" class="logo-item"
                                       @if ($copy > 0) aria-hidden="true" tabindex="-1" @endif>
                                        <div class="logo-box">
                                            @if ($b->logo)
                                                <img src="{{ $b->logo }}" alt="{{ $b->name }}" loading="lazy">
                                            @else
                                                <strong>{{ $b->name }}</strong>
                                            @endif
                                        </div>
                                        <span class="logo-name">{{ $b->name }}</span>
                                        <span class="logo-country">{{ $b->country }}</span>
                                    </a>
                                @endforeach
                            @endfor
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>
</section>

{{-- CTA band --}}
<section class="cx">
    <div class="container cx-in">
        <div>
            <h2>Let's Build a Smarter Future Together</h2>
            <p>Get in touch with our team for expert advice and tailored solutions.</p>
        </div>
        <a href="{{ route('contact') }}" class="cx-btn">Contact Us <i class="bi bi-arrow-right"></i></a>
    </div>
</section>

@endsection