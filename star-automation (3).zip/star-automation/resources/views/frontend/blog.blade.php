@extends('layouts.app')
@section('title', 'About Us | Star Automation')
@section('content')
<section class="section">
    <div class="container">
        <h1>About Us</h1>
        <p>Content yahan aayega.</p>
    </div>
</section>
@endsection