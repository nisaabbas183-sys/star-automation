@extends('layouts.app')

@section('title', 'Contact Star Automation | Request a Quote in Pakistan')
@section('description', 'Contact Star Automation in Lahore for industrial instruments, PLC, SCADA and automation engineering. Request a quote today.')

@section('content')

<section class="page-banner">
    @include('partials.banner-art')
    <div class="container">
        <nav class="crumbs">
            <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>Contact</span>
        </nav>
        <h1>Contact Us</h1>
        <p>Tell us your requirement and our engineers will get back to you.</p>
    </div>
</section>

<section class="section">
    <div class="container contact-grid">

        <div class="contact-info">
           <span class="eyebrow">Get in touch</span>
<h2>Our Contact Details</h2>
<p>Call, email or message us on WhatsApp, or visit our office in Lahore.</p>
            <ul class="contact-list">
                <li>
                    <span class="ci"><i class="bi bi-geo-alt"></i></span>
                    <div>
                        <strong>Address</strong>
                        <span>House#2, Tariq Ismaeel Rd., Near Gate#3, Gulshan-E-Lahore, Lahore, Pakistan</span>
                    </div>
                </li>
                <li>
                    <span class="ci"><i class="bi bi-telephone"></i></span>
                    <div>
                        <strong>Phone</strong>
                        <a href="tel:+924235525931">+92-42-35525931/32</a>
                    </div>
                </li>
                <li>
                    <span class="ci"><i class="bi bi-envelope"></i></span>
                    <div>
                        <strong>Email</strong>
                        <a href="mailto:sales@starautomation.net">sales@starautomation.net</a>
                    </div>
                </li>
                <li>
                    <span class="ci ci-wa"><i class="bi bi-whatsapp"></i></span>
                    <div>
                        <strong>WhatsApp</strong>
                        <a href="https://wa.me/923214988683" target="_blank" rel="noopener">Chat with us</a>
                    </div>
                </li>
            </ul>
        </div>

        <div class="form-card" id="quote-form">
            <div class="form-title">
    <h3>Request a Quote</h3>
    <p>Send us your requirement, product name or project details. We will reply as soon as possible.</p>
</div>
            @if (session('success'))
                <div class="alert alert-success"><i class="bi bi-check-circle-fill"></i> {{ session('success') }}</div>
            @endif

            @if ($errors->any())
                <div class="alert alert-error"><i class="bi bi-exclamation-circle-fill"></i> Please check the fields marked below.</div>
            @endif

            <form method="POST" action="{{ route('contact.send') }}">
                @csrf

                <div class="hp" aria-hidden="true">
                    <label>Website</label>
                    <input type="text" name="website" tabindex="-1" autocomplete="off">
                </div>

                <div class="form-row">
                    <div class="field">
                        <label for="name">Full name *</label>
                        <input type="text" id="name" name="name" value="{{ old('name') }}" required>
                        @error('name') <small class="err">{{ $message }}</small> @enderror
                    </div>
                    <div class="field">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" value="{{ old('email') }}" required>
                        @error('email') <small class="err">{{ $message }}</small> @enderror
                    </div>
                </div>

                <div class="form-row">
                    <div class="field">
                        <label for="phone">Phone</label>
                        <input type="text" id="phone" name="phone" value="{{ old('phone') }}">
                        @error('phone') <small class="err">{{ $message }}</small> @enderror
                    </div>
                    <div class="field">
                        <label for="company">Company</label>
                        <input type="text" id="company" name="company" value="{{ old('company') }}">
                        @error('company') <small class="err">{{ $message }}</small> @enderror
                    </div>
                </div>

                <div class="field">
                    <label for="product">Product or service</label>
                    <input type="text" id="product" name="product" value="{{ old('product', $product) }}" placeholder="e.g. Pressure Transmitters">
                    @error('product') <small class="err">{{ $message }}</small> @enderror
                </div>

                <div class="field">
                    <label for="message">Your message *</label>
                    <textarea id="message" name="message" rows="5" required>{{ old('message') }}</textarea>
                    @error('message') <small class="err">{{ $message }}</small> @enderror
                </div>

                <button type="submit" class="btn btn-primary btn-icon"><i class="bi bi-send"></i> Send Message</button>
            </form>
        </div>

    </div>
</section>

<section class="contact-map">
    <div class="container">
        <iframe
            title="Star Automation location"
            src="https://www.google.com/maps?q=House+2+Tariq+Ismaeel+Road+Gulshan-e-Lahore+Lahore+Pakistan&output=embed"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</section>
@if (session('success') || $errors->any())
    <script>
        document.getElementById('quote-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
    </script>
@endif
@endsection