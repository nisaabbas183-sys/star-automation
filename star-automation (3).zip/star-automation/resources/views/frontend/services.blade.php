@extends('layouts.app')

@section('title', 'Industrial Automation, Supplies & Software Services in Pakistan | Star Automation')
@section('description', 'Industrial instruments supply, automation engineering, PLC and SCADA, and customized software development in Pakistan.')

@section('content')

@php
$services = [
    [
        'image'  => 'industrial-supplies.jpg',
        'icon'   => 'bi-box-seam',
        'tag'    => 'Industrial Supplies',
        'title'  => 'Instruments and control equipment you can rely on',
        'text'   => 'We supply process equipment from leading manufacturers in the Far East, Europe and America.',
        'points' => [
            'Pressure, flow, temperature, level and humidity instruments',
            'Analyzers, valves and controllers',
            'Recorders, dataloggers, VFDs and sensors',
            'Breakers, contactors and relays',
        ],
        'link'   => ['route' => 'products', 'label' => 'View Products'],
    ],
    [
        'image'  => 'export.png',
        'icon'   => 'bi-diagram-3',
        'tag'    => 'Automation Engineering',
        'title'  => 'From installation to commissioning',
        'text'   => 'Our own engineers configure and commission systems for industries, factories and buildings across Pakistan.',
        'points' => [
            'Industrial, factory and building automation',
            'PLC and HMI based control systems',
            'Online SCADA with live trends, reports and alarms',
            'Alerts by SMS and email, monitoring 24/7',
        ],
        'link'   => ['route' => 'contact', 'label' => 'Get a Quote'],
    ],
    [
        'image'  => 'software-development.jpg',
        'icon'   => 'bi-code-slash',
        'tag'    => 'Software Development',
        'title'  => 'Customized software for your business',
        'text'   => 'We build web-based systems that fit the way your organization works.',
        'points' => [
            'Education and task management systems',
            'Accounts, inventory and quotation systems',
            'Dashboards and reports',
            'Customized software on demand',
        ],
        'link'   => ['route' => 'contact', 'label' => 'Get a Quote'],
    ],
];
@endphp

<section class="page-banner">
    @include('partials.banner-art')
    <div class="container">
        <nav class="crumbs">
            <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>Services</span>
        </nav>
        <h1>Our Services</h1>
        <p>Supplies, engineering and software under one roof.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        @foreach ($services as $s)
            <div class="svc-row">
                <figure class="svc-photo">
                    <img src="{{ asset('images/activities/' . $s['image']) }}" alt="{{ $s['tag'] }}" loading="lazy">
                </figure>

                <div class="svc-text">
                    <span class="svc-tag"><i class="bi {{ $s['icon'] }}"></i> {{ $s['tag'] }}</span>
                    <h2>{{ $s['title'] }}</h2>
                    <p>{{ $s['text'] }}</p>

                    <ul class="about-points">
                        @foreach ($s['points'] as $point)
                            <li><i class="bi bi-check-circle-fill"></i> {{ $point }}</li>
                        @endforeach
                    </ul>

                    <a href="{{ route($s['link']['route']) }}" class="btn btn-primary">{{ $s['link']['label'] }}</a>
                </div>
            </div>
        @endforeach
    </div>
</section>

@endsection