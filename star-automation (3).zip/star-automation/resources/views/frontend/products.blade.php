@extends('layouts.app')

@section('title', 'Industrial Instruments & Control Products in Pakistan | Star Automation')
@section('description', 'Pressure, flow, temperature, level and humidity instruments, analyzers, valves, controllers and VFDs supplied in Pakistan.')

@section('content')

@php
$icons = [
    'pressure' => 'bi-speedometer2', 'flow' => 'bi-droplet-half', 'temperature' => 'bi-thermometer-half',
    'level' => 'bi-water', 'humidity' => 'bi-moisture', 'analyzers' => 'bi-activity',
    'dataloggers' => 'bi-hdd-network', 'valves' => 'bi-gear-wide-connected', 'controllers' => 'bi-cpu',
    'switches-sensors' => 'bi-toggles', 'vfds' => 'bi-lightning-charge', 'breakers' => 'bi-plug',
    'contactors' => 'bi-diagram-2', 'relays' => 'bi-toggle-on',
];
@endphp

<section class="page-banner">
     <svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <symbol id="banner-gear" viewBox="0 0 200 200">
        <path fill="currentColor" fill-rule="evenodd" d="M177.0 87.8 L195.6 91.5 L195.6 108.5 L177.0 112.2 L172.8 128.0 L187.1 140.4 L178.5 155.2 L160.6 149.1 L149.1 160.6 L155.2 178.5 L140.4 187.1 L128.0 172.8 L112.2 177.0 L108.5 195.6 L91.5 195.6 L87.8 177.0 L72.0 172.8 L59.6 187.1 L44.8 178.5 L50.9 160.6 L39.4 149.1 L21.5 155.2 L12.9 140.4 L27.2 128.0 L23.0 112.2 L4.4 108.5 L4.4 91.5 L23.0 87.8 L27.2 72.0 L12.9 59.6 L21.5 44.8 L39.4 50.9 L50.9 39.4 L44.8 21.5 L59.6 12.9 L72.0 27.2 L87.8 23.0 L91.5 4.4 L108.5 4.4 L112.2 23.0 L128.0 27.2 L140.4 12.9 L155.2 21.5 L149.1 39.4 L160.6 50.9 L178.5 44.8 L187.1 59.6 L172.8 72.0 Z M132 100 A32 32 0 1 0 68 100 A32 32 0 1 0 132 100 Z"/>
    </symbol>
</svg>
<svg class="bgear bgear-1" viewBox="0 0 200 200" aria-hidden="true"><use href="#banner-gear"/></svg>
<svg class="bgear bgear-2" viewBox="0 0 200 200" aria-hidden="true"><use href="#banner-gear"/></svg>
<svg class="banner-wave" viewBox="0 0 1200 60" preserveAspectRatio="none" aria-hidden="true">
    <path pathLength="1000" d="M0 40 H300 L320 40 L340 12 L364 54 L384 40 H640 L660 40 L680 14 L704 52 L724 40 H980 L1000 40 L1020 12 L1044 54 L1064 40 H1200"/>
</svg>
    <div class="container">
       <nav class="crumbs">
    <a href="{{ route('home') }}"><i class="bi bi-house"></i> Home</a>
    <i class="bi bi-chevron-right sep"></i>
    <span>Products</span>
</nav>
        <h1>Our Products</h1>
        <p>Instruments and control products from leading international principals.</p>
    </div>
</section>

<section class="section section-soft">
    <div class="container">
        <div class="catalog">
            <aside class="catalog-nav">
                @foreach ($categories as $i => $category)
                    <button type="button" class="catalog-item {{ $i === 0 ? 'is-active' : '' }}" data-tab="{{ $category->slug }}">
                        <i class="bi {{ $icons[$category->slug] ?? 'bi-box-seam' }}"></i>
                        <span>{{ $category->name }}</span>
                        <em>{{ $category->products->count() }}</em>
                    </button>
                @endforeach
            </aside>

            <div class="catalog-body">
                @foreach ($categories as $i => $category)
                    <div class="tab-panel {{ $i === 0 ? 'is-active' : '' }}" data-panel="{{ $category->slug }}">
                        <div class="catalog-head">
                            <h3>{{ $category->name }}</h3>
                            <span>{{ $category->products->count() }} products</span>
                        </div>

                        <div class="product-grid">
                            @foreach ($category->products as $product)
                                <a href="{{ route('product.show', $product->slug) }}" class="product-card">
                                    <div class="product-img">
                                        @if ($product->short_description)
                                            <span class="product-tag">{{ $product->short_description }}</span>
                                        @endif

                                        @if ($product->image)
                                            <img src="{{ asset('images/products/' . $product->image) }}" alt="{{ $product->name }}" loading="lazy">
                                        @else
                                            <span class="no-image">Image coming soon</span>
                                        @endif
                                    </div>
                                    <div class="product-body">
                                        <h3>{{ $product->name }}</h3>
                                        <span class="product-link">View Details →</span>
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</section>

@endsection