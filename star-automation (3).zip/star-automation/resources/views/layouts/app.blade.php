<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Star Automation')</title>
    <meta name="description" content="@yield('description', 'Industrial automation, building automation, PLC and SCADA in Pakistan.')">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/theme.css') }}">
</head>
<body>

@php
$nav = [
    ['home','Home'],['about','About'],['products','Products'],['brands','Brands'],
       ['services','Services'],['projects','Projects'],['contact','Contact'],
];
@endphp
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-left">
            <a href="tel:+924235525931"><i class="bi bi-telephone"></i> +92-42-35525931/32</a>
            <a href="mailto:sales@starautomation.net"><i class="bi bi-envelope"></i> sales@starautomation.net</a>
        </div>
      <div class="topbar-right">
    <span><i class="bi bi-geo-alt"></i> Gulshan-E-Lahore, Lahore, Pakistan</span>

    <div class="topbar-social">
        <a href="https://wa.me/923214988683" class="soc soc-wa" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
        <a href="https://www.facebook.com/Star-Automation-261254404666785" class="soc soc-fb" target="_blank" rel="noopener" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
        <a href="https://www.linkedin.com/company/star-automation-pakistan/" class="soc soc-in" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a>
    </div>
</div>
    </div>
</div>
<header class="site-header">
    <div class="container navbar">
        <a class="logo" href="{{ route('home') }}">
            <img src="{{ asset('images/logo.png') }}" alt="Star Automation">
        </a>

        <nav class="desktop-nav">
            @foreach ($nav as $n)
                <a href="{{ route($n[0]) }}" class="{{ request()->routeIs($n[0]) ? 'active' : '' }}">{{ $n[1] }}</a>
            @endforeach
        </nav>

        <a class="nav-contact" href="{{ route('contact') }}">Get a Quote <span>→</span></a>

        <details class="mobile-menu">
            <summary>Menu</summary>
            <div class="mobile-links">
                @foreach ($nav as $n)
                    <a href="{{ route($n[0]) }}">{{ $n[1] }}</a>
                @endforeach
            </div>
        </details>
    </div>
</header>

<main>
    @yield('content')
</main>

<footer class="site-footer">
    <div class="container footer-grid">
        <div class="footer-brand">
            <a class="footer-logo" href="{{ route('home') }}">
                <img src="{{ asset('images/logo.png') }}" alt="Star Automation">
            </a>
            <p>Industrial, factory and building automation, instruments and customized software. Lahore, Pakistan.</p>
        </div>

        <div class="footer-column">
            <h4>Brands</h4>
            <a href="{{ route('brands') }}">Dwyer Omega in Pakistan</a>
            <a href="{{ route('brands') }}">Azbil in Pakistan</a>
            <a href="{{ route('brands') }}">SCHUF in Pakistan</a>
            <a href="{{ route('brands') }}">Mitsubishi Electric in Pakistan</a>
        </div>

        <div class="footer-column">
            <h4>Services</h4>
            <a href="{{ route('services') }}">Industrial Automation in Pakistan</a>
            <a href="{{ route('services') }}">Building Automation in Pakistan</a>
            <a href="{{ route('services') }}">PLC in Pakistan</a>
            <a href="{{ route('services') }}">SCADA in Pakistan</a>
        </div>

       <div class="footer-column">
    <h4>Contact</h4>
    <p class="ft-line"><i class="bi bi-geo-alt"></i><span>House#2, Tariq Ismaeel Rd., Near Gate#3, Gulshan-E-Lahore, Lahore, Pakistan</span></p>
    <a href="tel:+924235525931" class="ft-line"><i class="bi bi-telephone"></i><span>+92-42-35525931/32</span></a>
    <a href="mailto:sales@starautomation.net" class="ft-line"><i class="bi bi-envelope"></i><span>sales@starautomation.net</span></a>

    <div class="ft-social">
        <a href="https://wa.me/923214988683" class="s-wa" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
        <a href="https://www.facebook.com/Star-Automation-261254404666785" class="s-fb" target="_blank" rel="noopener" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
        <a href="https://www.linkedin.com/company/star-automation-pakistan/" class="s-in" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="bi bi-linkedin"></i></a>
    </div>
</div>
    </div>

    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <p>© {{ date('Y') }} Star Automation. All rights reserved.</p>
            <p>Lahore, Pakistan</p>
        </div>
    </div>
</footer>
<script src="{{ asset('js/script.js') }}"></script>
</body>
</html>