

<?php $__env->startSection('title', $product->name . ' in Pakistan | Star Automation'); ?>
<?php $__env->startSection('description', $product->name . ' supplied and supported by Star Automation, Lahore, Pakistan.'); ?>

<?php $__env->startSection('content'); ?>

<section class="product-head">
    <div class="container">
        <nav class="crumbs">
            <a href="<?php echo e(route('home')); ?>"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <a href="<?php echo e(route('products')); ?>">Products</a>
            <i class="bi bi-chevron-right sep"></i>
            <span><?php echo e($product->category->name); ?></span>
        </nav>
    </div>
</section>

<section class="section">
    <div class="container pd">
        <div class="pd-image">
            <?php if($product->image): ?>
                <img src="<?php echo e(asset('images/products/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
            <?php else: ?>
                <span class="no-image">Image coming soon</span>
            <?php endif; ?>
        </div>

        <div class="pd-info">
            <span class="pd-cat"><?php echo e($product->category->name); ?></span>
            <h1><?php echo e($product->name); ?></h1>
            <?php if($product->short_description): ?>
                <p class="pd-type"><?php echo e($product->short_description); ?></p>
            <?php endif; ?>

            <table class="pd-table">
                <tr>
                    <th>Category</th>
                    <td><?php echo e($product->category->name); ?></td>
                </tr>
                <?php if($product->short_description): ?>
                    <tr>
                        <th>Type</th>
                        <td><?php echo e($product->short_description); ?></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th>Supplied by</th>
                    <td>Star Automation, Lahore, Pakistan</td>
                </tr>
                <tr>
                    <th>Services</th>
                    <td>Application, installation, configuration and commissioning</td>
                </tr>
            </table>

           <div class="pd-actions">
    <a href="<?php echo e(route('contact', ['product' => $product->name])); ?>" class="btn btn-primary btn-icon">
        <i class="bi bi-envelope-paper"></i> Request a Quote
    </a>
    <a href="https://wa.me/923214988683?text=<?php echo e(urlencode('Hello, I would like a quote for: ' . $product->name)); ?>" class="btn btn-whatsapp btn-icon" target="_blank" rel="noopener">
        <i class="bi bi-whatsapp"></i> WhatsApp
    </a>
</div>
        </div>
    </div>
</section>

<?php if($related->isNotEmpty()): ?>
<section class="section section-soft">
    <div class="container">
        <span class="eyebrow">More in <?php echo e($product->category->name); ?></span>
        <h2>Related Products</h2>

        <div class="product-grid" style="margin-top:28px">
            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('product.show', $item->slug)); ?>" class="product-card">
                    <div class="product-img">
                        <?php if($item->short_description): ?>
                            <span class="product-tag"><?php echo e($item->short_description); ?></span>
                        <?php endif; ?>
                        <?php if($item->image): ?>
                            <img src="<?php echo e(asset('images/products/' . $item->image)); ?>" alt="<?php echo e($item->name); ?>" loading="lazy">
                        <?php else: ?>
                            <span class="no-image">Image coming soon</span>
                        <?php endif; ?>
                    </div>
                    <div class="product-body">
                        <h3><?php echo e($item->name); ?></h3>
                        <span class="product-link">View Details →</span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\star-automation\resources\views/frontend/product.blade.php ENDPATH**/ ?>