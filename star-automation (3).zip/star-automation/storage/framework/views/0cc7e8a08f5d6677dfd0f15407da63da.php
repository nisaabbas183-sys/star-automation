

<?php $__env->startSection('title', 'International Brands We Represent in Pakistan | Star Automation'); ?>
<?php $__env->startSection('description', 'Star Automation represents Azbil, Dwyer Omega, Mitsubishi Electric, SCHUF, GF Piping, Daiichi, Kinda and B&C Electronics in Pakistan.'); ?>

<?php $__env->startSection('content'); ?>

<section class="page-banner">
    <?php echo $__env->make('partials.banner-art', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container">
        <nav class="crumbs">
            <a href="<?php echo e(route('home')); ?>"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>Brands</span>
        </nav>
        <h1>Our Brands</h1>
        <p>International principals we represent in Pakistan.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <span class="eyebrow">Partners</span>
        <h2>Equipment from leading Manufacturers</h2>
        <p class="section-intro">We supply, configure and support products from trusted manufacturers around the world.</p>

        <div class="brand-grid">
    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('contact', ['product' => $brand->name])); ?>" class="tile" id="<?php echo e($brand->slug); ?>" title="Request a quote for <?php echo e($brand->name); ?>">
            <span class="tile-arrow"><i class="bi bi-arrow-up-right"></i></span>

            <span class="tile-logo">
                <?php if($brand->logo): ?>
                    <img src="<?php echo e(asset('images/brands/' . $brand->logo)); ?>" alt="<?php echo e($brand->name); ?>" loading="lazy">
                <?php else: ?>
                    <i class="bi bi-gear-wide-connected"></i>
                <?php endif; ?>
            </span>

            <span class="tile-meta">
                <strong><?php echo e($brand->name); ?></strong>
                <em><i class="bi bi-geo-alt"></i> <?php echo e($brand->country); ?></em>
            </span>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
        
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\star-automation\resources\views/frontend/brands.blade.php ENDPATH**/ ?>