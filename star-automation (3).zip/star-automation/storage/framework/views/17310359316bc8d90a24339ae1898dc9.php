

<?php $__env->startSection('title', 'Industrial Automation, Supplies & Software Services in Pakistan | Star Automation'); ?>
<?php $__env->startSection('description', 'Industrial instruments supply, automation engineering, PLC and SCADA, and customized software development in Pakistan.'); ?>

<?php $__env->startSection('content'); ?>

<?php
$services = [
    [
        'image'  => 'industrial-supplies.jpg',
        'icon'   => 'bi-box-seam',
        'tag'    => 'Industrial Supplies',
        'title'  => 'Instruments and control equipment you can rely on',
        'text'   => 'We supply process equipment from leading manufacturers in the Far East, Europe and America.',
        'points' => [
            'Pressure, flow, temperature, level and humidity instruments',
            'Analyzers, valves and controllers',
            'Recorders, dataloggers, VFDs and sensors',
            'Breakers, contactors and relays',
        ],
        'link'   => ['route' => 'products', 'label' => 'View Products'],
    ],
    [
        'image'  => 'export.png',
        'icon'   => 'bi-diagram-3',
        'tag'    => 'Automation Engineering',
        'title'  => 'From installation to commissioning',
        'text'   => 'Our own engineers configure and commission systems for industries, factories and buildings across Pakistan.',
        'points' => [
            'Industrial, factory and building automation',
            'PLC and HMI based control systems',
            'Online SCADA with live trends, reports and alarms',
            'Alerts by SMS and email, monitoring 24/7',
        ],
        'link'   => ['route' => 'contact', 'label' => 'Get a Quote'],
    ],
    [
        'image'  => 'software-development.jpg',
        'icon'   => 'bi-code-slash',
        'tag'    => 'Software Development',
        'title'  => 'Customized software for your business',
        'text'   => 'We build web-based systems that fit the way your organization works.',
        'points' => [
            'Education and task management systems',
            'Accounts, inventory and quotation systems',
            'Dashboards and reports',
            'Customized software on demand',
        ],
        'link'   => ['route' => 'contact', 'label' => 'Get a Quote'],
    ],
];
?>

<section class="page-banner">
    <?php echo $__env->make('partials.banner-art', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="container">
        <nav class="crumbs">
            <a href="<?php echo e(route('home')); ?>"><i class="bi bi-house"></i> Home</a>
            <i class="bi bi-chevron-right sep"></i>
            <span>Services</span>
        </nav>
        <h1>Our Services</h1>
        <p>Supplies, engineering and software under one roof.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="svc-row">
                <figure class="svc-photo">
                    <img src="<?php echo e(asset('images/activities/' . $s['image'])); ?>" alt="<?php echo e($s['tag']); ?>" loading="lazy">
                </figure>

                <div class="svc-text">
                    <span class="svc-tag"><i class="bi <?php echo e($s['icon']); ?>"></i> <?php echo e($s['tag']); ?></span>
                    <h2><?php echo e($s['title']); ?></h2>
                    <p><?php echo e($s['text']); ?></p>

                    <ul class="about-points">
                        <?php $__currentLoopData = $s['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><i class="bi bi-check-circle-fill"></i> <?php echo e($point); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <a href="<?php echo e(route($s['link']['route'])); ?>" class="btn btn-primary"><?php echo e($s['link']['label']); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\star-automation\resources\views/frontend/services.blade.php ENDPATH**/ ?>