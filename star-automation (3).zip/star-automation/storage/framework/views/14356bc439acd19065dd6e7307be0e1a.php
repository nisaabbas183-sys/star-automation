<svg width="0" height="0" style="position:absolute" aria-hidden="true">
    <symbol id="banner-gear" viewBox="0 0 200 200">
        <path fill="currentColor" fill-rule="evenodd" d="M177.0 87.8 L195.6 91.5 L195.6 108.5 L177.0 112.2 L172.8 128.0 L187.1 140.4 L178.5 155.2 L160.6 149.1 L149.1 160.6 L155.2 178.5 L140.4 187.1 L128.0 172.8 L112.2 177.0 L108.5 195.6 L91.5 195.6 L87.8 177.0 L72.0 172.8 L59.6 187.1 L44.8 178.5 L50.9 160.6 L39.4 149.1 L21.5 155.2 L12.9 140.4 L27.2 128.0 L23.0 112.2 L4.4 108.5 L4.4 91.5 L23.0 87.8 L27.2 72.0 L12.9 59.6 L21.5 44.8 L39.4 50.9 L50.9 39.4 L44.8 21.5 L59.6 12.9 L72.0 27.2 L87.8 23.0 L91.5 4.4 L108.5 4.4 L112.2 23.0 L128.0 27.2 L140.4 12.9 L155.2 21.5 L149.1 39.4 L160.6 50.9 L178.5 44.8 L187.1 59.6 L172.8 72.0 Z M132 100 A32 32 0 1 0 68 100 A32 32 0 1 0 132 100 Z"/>
    </symbol>
</svg>
<svg class="bgear bgear-1" viewBox="0 0 200 200" aria-hidden="true"><use href="#banner-gear"/></svg>
<svg class="bgear bgear-2" viewBox="0 0 200 200" aria-hidden="true"><use href="#banner-gear"/></svg>
<svg class="banner-wave" viewBox="0 0 1200 60" preserveAspectRatio="none" aria-hidden="true">
    <path pathLength="1000" d="M0 40 H300 L320 40 L340 12 L364 54 L384 40 H640 L660 40 L680 14 L704 52 L724 40 H980 L1000 40 L1020 12 L1044 54 L1064 40 H1200"/>
</svg><?php /**PATH D:\star-automation\resources\views/partials/banner-art.blade.php ENDPATH**/ ?>