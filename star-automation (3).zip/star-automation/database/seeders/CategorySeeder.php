<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $names = [
            'Pressure', 'Flow', 'Temperature', 'Level', 'Humidity', 'Analyzers', 'Dataloggers',
            'Valves', 'Controllers', 'Switches & Sensors', 'VFDs', 'Breakers', 'Contactors', 'Relays',
        ];

        foreach ($names as $i => $name) {
            Category::updateOrCreate(
                ['slug' => Str::slug($name)],
                ['name' => $name, 'sort_order' => $i]
            );
        }
    }
}