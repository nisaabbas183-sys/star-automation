<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        Product::query()->delete();

        // 'Category name' => [ [product name, image file, optional note], ... ]
        $catalog = [
            'Pressure' => [
                ['Pressure & Differential Pressure Transmitters', 'p-01.jpg'],
                ['Remote Seal Transmitters', 'p-66.jpg'],
                ['Flanged Transmitters', 'p-68.jpg'],
                ['Pressure Transmitters', 'p-03.jpg'],
                ['Pressure & Differential Pressure Transmitters', 'p-05.jpg'],
                ['Differential Pressure Transmitters', 'p-73.jpg'],
                ['Digital Pressure Gauges & Transmitters', 'p-74.jpg'],
                ['Digital Pressure Transmitters', 'p-75.jpg'],
                ['Pressure & Differential Pressure Gauges', 'p-07.jpg'],
                ['Differential Pressure Switches', 'p-09.jpg'],
                ['Pressure Switches', 'p-76.jpg'],
                ['Pneumatic Transmitters', 'p-10.jpg'],
            ],
            'Flow' => [
                ['Electromagnetic Flow Meters', 'p-02.jpg'],
                ['Rotameters', 'p-32.jpg'],
                ['Electromagnetic Flow Meters', 'p-52.jpg', 'Insertion type'],
                ['Gas Flow Meters', 'p-53.jpg', 'Vortex type'],
                ['Liquid Flow Meters', 'p-54.jpg', 'Vortex type'],
                ['Coriolis Flow Meters', 'p-55.jpg'],
                ['Thermal Gas Flow Meters', 'p-51.jpg'],
                ['BTU Meters', 'p-46.jpg'],
                ['Flow Transmitters', 'p-47.jpg'],
                ['Ultrasonic Flow Meters', 'p-48.jpg'],
                ['Turbine Flow Meters', null, 'Insertion type'],
                ['Flow Switches', 'p-33.jpg'],
                ['Electromagnetic Flow Meter', 'p-flow-electromagnetic.jpg'],
                ['Paddle Wheel Flow Meter', 'p-flow-paddle-2.jpg'],
                ['Paddle Wheel Flow Meter', 'p-flow-paddle.jpg'],
            ],
            'Temperature' => [
                ['Temperature Gauges', 'p-71.jpg'],
                ['Temperature Gauges', 'p-72.jpg'],
                ['Programmable Thermostats', 'p-60.jpg'],
                ['Temperature Sensors', 'p-61.jpg'],
                ['Temperature Sensors', 'p-62.jpg'],
                ['Industrial Thermometers', 'p-84.jpg'],
                ['Thermocouple Thermometers', 'p-63.jpg', 'Dual input'],
                ['Temperature Transmitters', 'p-temp-tt1.jpeg'],
                ['Temperature Transmitters', 'p-temp-tt2.jpeg'],
            ],
            'Level' => [
                ['Level Transmitters', 'p-41.jpg'],
                ['Ultrasonic Level Transmitters and Switches', 'p-42.jpg'],
                ['Level Gauges with Transmitters and Switches', 'p-43.jpg'],
                ['Level Transmitters', 'p-44.jpg', 'Displacer type'],
                ['Level Transmitters', 'p-45.jpg', 'Immersion type'],
                ['Level Switches', 'p-67.jpg', 'Tuning fork'],
                ['Level Switches', 'p-69.jpg'],
                ['Level Switches', 'p-70.jpg', 'Paddle type'],
            ],
            'Humidity' => [
                ['Humidity & Temperature Transmitters', 'p-11.jpg', 'Wall mount'],
                ['Humidity & Temperature Transmitters', 'p-12.jpg', 'Duct mount and outdoor'],
                ['Humidity & Temperature Transmitters', 'p-82.jpg', 'Indoor'],
                ['Humidity & Temperature Transmitters', 'p-13.jpg', 'Duct mount'],
                ['Air Velocity Transmitters', 'p-40.jpg', 'Duct mount'],
            ],
            'Analyzers' => [
                ['Gas Detectors', 'p-14.jpg'],
                ['Gas Analyzers', 'p-34.jpg'],
                ['Analyzer Transmitters & Controllers', 'p-15.jpg'],
                ['Analyzer Controllers', 'p-16.jpg'],
                ['Analyzer Sensors', 'p-17.jpg'],
            ],
            'Dataloggers' => [
                ['Dataloggers', 'p-37.jpg'],
                ['Recorders', 'p-38.jpg'],
                ['Portable Dataloggers', 'p-39.jpg'],
                ['Portable Dataloggers', 'p-80.jpg'],
                ['Energy Dataloggers', 'p-81.jpg'],
            ],
            'Valves' => [
                ['Control Valves', 'p-04.jpg'],
                ['RAM Bottom Outlet Valves', 'p-27.jpg'],
                ['Lift Plug Valves', 'p-28.jpg'],
                ['Automatic Recirculation Valves', 'p-29.jpg'],
                ['Flush Bottom Outlet Disc Valves', 'p-59.jpg'],
                ['Control Valves', 'p-58.jpg'],
                ['Sampling Valves', 'p-57.jpg'],
                ['Manifold Selector Valves', 'p-30.jpg'],
                ['Safety Valves', null],
                ['Cryogenic Safety Valves', 'p-86.jpg'],
                ['Interlocked Valves', 'p-83.jpg'],
                ['Smart Valve Positioners', 'p-31.jpg', 'With digital display'],
                ['Smart Valve Positioners', 'p-35.jpg'],
                ['Solenoid Valves', 'p-79.jpg'],
                ['Control Valves', 'p-cv-22.jpg'],
                ['Control Valves', 'p-cv-88.jpg'],
                ['Control Valves', 'p-cv-99.jpg'],
                ['Control Valves', 'p-cv-111.jpg'],
            ],
            'Controllers' => [
                ['Burner Controllers & Network Controllers', 'p-18.jpg'],
                ['Multichannel Controllers', 'p-multichannel.jpg'],
                ['Burner Controllers', 'p-36.jpg'],
                ['PID Controllers', 'p-19.jpg'],
                ['Multi Loop Controllers', 'p-20.jpg'],
                ['Flame Detectors & Burner Controllers', 'p-21.jpg'],
                ['Temperature Indicators & Controllers', 'p-78.jpg'],
                ['Temperature Indicators & Controllers', 'p-121.jpg'],
                ['Fatek PLC', 'p-fatek-plc.jpg'],
                ['Mitsubishi PLC', 'p-mitsubishi-plc.png'],
                ['Energy Meters', 'p-energy-meter.jpeg'],
                ['Servo Drives', 'p-servo-drives.jpeg'],
                ['HMI', 'p-hmi.jpeg'],
                ['Siemens PLC', 'p-siemens-plc.jpg'],
            ],
            'Switches & Sensors' => [
                ['Earthquake Sensors', 'p-22.jpg'],
                ['Distance Sensors', 'p-23.jpg'],
                ['Proximity Sensors', 'p-24.jpg'],
                ['Proximity Sensors', 'p-25.jpg'],
                ['GF Piping Products', 'p-gf-1.jpeg'],
                ['GF Piping Products', 'p-gf-2.jpeg'],
                ['Limit Switches', 'p-26.jpg'],
            ],
            'VFDs' => [
                ['Variable Frequency Drives (VFD)', 'p-64.jpg'],
                ['Variable Frequency Drives (VFD)', 'p-vfd-vf.jpeg'],
                ['Variable Frequency Drives (VFD)', 'p-65.jpg'],
            ],
            'Breakers' => [
                ['Air Circuit Breakers (ACB)', 'p-acb.png'],
                ['Moulded Case Circuit Breakers (MCCB)', 'p-mccb.jpg'],
                ['Miniature Circuit Breakers (MCB)', 'p-mcb.jpg'],
            ],
            'Contactors' => [
                ['Mitsubishi Magnetic Contactors', 'p-contactors.png'],
            ],
            'Relays' => [
                ['Thermal Overload Relays', 'p-relay-1.jpeg'],
                ['Thermal Overload Relays', 'p-relay-2.jpeg'],
            ],
        ];

        foreach ($catalog as $categoryName => $items) {
            $category = Category::where('name', $categoryName)->first();

            if (! $category) {
                $this->command->warn("Category not found: {$categoryName}");
                continue;
            }

            foreach ($items as $index => $item) {
                $name  = $item[0];
                $image = $item[1];
                $note  = $item[2] ?? null;

                Product::create([
                    'category_id'       => $category->id,
                    'name'              => $name,
                    'slug'              => Str::slug($name . ' ' . $categoryName . ' ' . ($index + 1)),
                    'image'             => $image,
                    'short_description' => $note,
                    'is_featured'       => false,
                ]);
            }
        }
    }
}