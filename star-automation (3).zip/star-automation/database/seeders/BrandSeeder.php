<?php

namespace Database\Seeders;

use App\Models\Brand;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class BrandSeeder extends Seeder
{
    public function run(): void
    {
        $brands = [
            ['Azbil', 'Japan', 'azbil.png'],
            ['Mitsubishi Electric', 'Japan', 'mitsubishi-electric.jpeg'],
            ['Dwyer Omega', 'USA', 'dwyer-omega.png'],
            ['SCHUF', 'Germany', 'schuf.png'],
            ['GF Piping', 'Switzerland', 'gf-piping.jpeg'],
            ['Daiichi', 'Japan', 'daiichi.jpg'],
            ['Kinda', 'China', 'kinda.jpg'],
            ['B&C Electronics', 'Italy', 'bc-electronics.jpg'],
        ];

        foreach ($brands as $i => [$name, $country, $logo]) {
            Brand::updateOrCreate(
                ['slug' => Str::slug($name)],
                ['name' => $name, 'country' => $country, 'logo' => $logo, 'sort_order' => $i]
            );
        }
    }
}