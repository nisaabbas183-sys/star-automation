<?php

namespace App\Http\Controllers;

use App\Models\Inquiry;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index(Request $request)
    {
        return view('frontend.contact', [
            'product' => $request->query('product'),
        ]);
    }

    public function store(Request $request)
    {
        // hidden field: real visitors leave it empty, spam bots fill it
        if ($request->filled('website')) {
            return redirect()->route('contact');
        }

        $data = $request->validate([
            'name'    => ['required', 'string', 'max:120'],
            'email'   => ['required', 'email', 'max:160'],
            'phone'   => ['nullable', 'string', 'max:40'],
            'company' => ['nullable', 'string', 'max:160'],
            'product' => ['nullable', 'string', 'max:200'],
            'message' => ['required', 'string', 'max:3000'],
        ]);

        Inquiry::create($data);

        return redirect()
            ->route('contact')
            ->with('success', 'Thank you! Your message has been received. Our team will contact you soon.');
    }
}