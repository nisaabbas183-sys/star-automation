<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Category;

class HomeController extends Controller
{
    public function index()
    {
        return view('frontend.home', [
            'categories' => Category::with('products')->orderBy('sort_order')->get(),
            'brands'     => Brand::orderBy('sort_order')->get(),
        ]);
    }
}