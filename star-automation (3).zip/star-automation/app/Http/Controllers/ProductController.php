<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        return view('frontend.products', [
            'categories' => Category::with('products')->orderBy('sort_order')->get(),
        ]);
    }

    public function show(Product $product)
    {
        $product->load('category');

        $related = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->orderBy('id')
            ->take(4)
            ->get();

        return view('frontend.product', [
            'product' => $product,
            'related' => $related,
        ]);
    }
}