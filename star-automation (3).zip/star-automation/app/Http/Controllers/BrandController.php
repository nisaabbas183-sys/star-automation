<?php

namespace App\Http\Controllers;

use App\Models\Brand;

class BrandController extends Controller
{
    public function index()
    {
        return view('frontend.brands', [
            'brands' => Brand::orderBy('sort_order')->get(),
        ]);
    }
}